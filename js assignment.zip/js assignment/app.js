// chapter #01

// alert('Welcome to a world classy Site');

// alert('Error! Please enter a valid password.');

// alert('Welcome to the JS land ... \n   Happy Coding!');

// for (var i = 0; i <= 1; i++) {
//     if(i === 0)
//     alert("Welcome to JS Land... ");

//     else{
//         alert("Prevent this page from creating this dialogs");
//     }

// }

// console.log( alert('Hello!I can run JS through my web browser console.'););


// chapter #02


// 01
// var userName;

// 02
// var myName;
// var str= "Hifza Maqsood Ahmed";
// myName=str;
// document.write(myName);

// 03
// var message="Hello World";
// alert(message);

// 04
// var name,age,courseCertified;
// name= "John Doe";
// age= "15 years old";
// courseCertified= "Certified Mobile application Development";
// alert(name);
// alert(age);
// alert(courseCertified);

// 05
// var fav= "PIZZA";
// alert(fav +"\n"+ fav[0]+ fav[1]+ fav[2]+ fav[3] + "\n" + fav[0]+ fav[1]+ fav[2] +  "\n" + fav[0]+ fav[1] + "\n" + fav[0] );


// 06
// var email= "example@example.com";
// alert("My email addresss is " +  email);

// 07
// var book= "A smarter way to learn JavaScript";
// alert("I am trying to learn from the Book " + book);

// 08
// document.write("Yah! I can write HTML content through JavaScript");


// 09
// var str = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
// alert(str);




// chapter #03

// 01
// var age= "I am 15 years old";
// alert(age);


// 02




// 03
// var birthYear= 1990;
// document.write(" My birthYear is " + birthYear + "<br> "  + "Data type of my declared variable is number" );


// 04
// var visitorName= "John Doe";
// var proTitle= "T-shirt(s)";
// var quantity= 5;
// document.write(visitorName + "  ordered  " + proTitle + " on XYZ Clothing Store");


// chapter #04

// 01
// var name,age,gender;

// 02
// 5 Legal Variables Names
// var name;
// var firstName;
// var full_name;
// var name2;
// var $name;

// 5 Illegal Variables Names
// var _name;
// var first name;
// var full-name;
// var 1name;
// var &name;

// 03 done in html file

// chapter #05

// 01
// var num1= 3;
// var num2= 5;
// var sum= num1 + num2;
// document.write("sum of 3 and 5 is " + sum);

// 02
// var num1= 5;
// var num2= 3;
// var sub= num1 - num2;
// document.write("Subtraction of 5 and 3 is " + sub);

// var num1= 5;
// var num2= 3;
// var mul= num1 * num2;
// document.write("Multiplication of 5 and 3 is " + mul);

// var num1= 5;
// var num2= 3;
// var div= num1 / num2;
// document.write("Division of 5 and 3 is " + div);

// var num1= 5;
// var num2= 3;
// var mod= num1 % num2;
// document.write("Division of 5 and 3 is " + mod);

// 03
// var num;
// document.write("Value after variable declaration is " + num + "<br>");
// num = 5;
// document.write("Initial value is: " + num + "<br>");
// num++;
// document.write( "Value after increment is: " + num + "<br>");
// num = num +7;
// document.write("Value after addition is: " + num + "<br>");
// num--;
// document.write("Value after decrement is: " + num + "<br>");
// num= num % 3;
// document.write( "The remainder is: " + num + "<br>");


// 04
// var cost= 600;
// cost= cost * 5;
// document.write("Total cost to buy 5 tickets to a movie is  " + cost + "PKR" );

// 05
// var num= 6;
// for(var i=1; i<=10; i++){
//   document.write("6" + "X" + i + "=" + num * i + "<br>");
// }

// 06 Celsius to Fahrenheit

// var C= 25; 
// var F= 70;
// F= (25 * 9/5)  + 32;
// document.write("25" + "<sup> 0 </sup> C" + " is " + F +  "<sup> 0 </sup> F");

//  Fahrenheit to Celsius
// var C= 27; 
// var F= 70;
// C= (70- 32) * 5/9 ;
// document.write("70" + "<sup> 0 </sup> F" + " is " + C +  "<sup> 0 </sup> C");

// 07
// var prz1stItem= 650;
// var prz2ndItem= 100;
// var firstItemQty= 3;
// var secondItemQty= 7;
// var shipChrgs= 100;
// var total;
// document.write("<h1>Shopping Cart</h1>");
// document.write("Price of item 1 is " + prz1stItem + "<br>");
// document.write("Quantity of item 1 is " + firstItemQty + "<br>");
// document.write("Price of item 2 is " + prz2ndItem + "<br>");
// document.write("Quantity of item 2 is " + secondItemQty  + "<br>");
// document.write("Quantity of item 2 is " + secondItemQty  + "<br>");
// document.write("Shipping Charges s" + shipChrgs + "<br> <br>");
// total= prz1stItem * firstItemQty + prz2ndItem * secondItemQty +shipChrgs;
// document.write("Total cost of your order is  " + total);

// 08
// var totalMarks= 980;
// var obtained= 804;
// var percentage= obtained/totalMarks * 100;
// document.write("<h1>Marks Sheet </h1>"  + "<br>");
// document.write("Total Marks: " + totalMarks + "<br>");
// document.write("Marks obtained: " + obtained + "<br>");
// document.write("Percentage: " + percentage + "%" );

// 09
// var $US= 104.80;
// var saudiRayal= 28;
// var pkr;
// pkr= $US * 10 + saudiRayal * 25;
// document.write("<h1>Currency in PKR</h1>  " +"<br>" );
// document.write("Total Currency in PKR:" + pkr );

// 10      something wrong
// var num= 10;
// num= num + (5 * 10) / 2;
// document.write(num );


// 11
// var currntYear= 2016;
// var birthYear= 1992;
// var age;
// document.write("<h1>Age Calculator </h1>" + "<br>" );
// document.write("Current Year: " + currntYear + "<br>" );
// document.write(" Birth Year: " + birthYear + "<br>" );
// age = currntYear - birthYear;
// document.write("Your age is: " + age );

// 12
// var radius = 20;
// const pi = 3.142;
// var circum;
// var area;
// circum = 2 * 3.142 * radius;
// area = 3.142 * radius * radius; 
// document.write("<h1> The Geometrizer </h1>" + "<br>");
// document.write("The Radius is: " + radius + "<br>");
// document.write("The Circumference is: " + circum + "<br>");
// document.write("The Area is: " + area + "<br>");

// 13
// var favSnack = "chocolate chip";
// var currentAge = 15;
// var maxAge = 65;
// var amntSnackPerDay = 3;
// var cacu = ( maxAge - currentAge ) * amntSnackPerDay;
// document.write("<h1>The Life Time Supply Calculator</h1> "  + "<br>");
// document.write("Current Age: "  + currentAge +"<br>");
// document.write("estimated Maximum Age: "  + maxAge +"<br>");
// document.write("Amount of Snacks per day: "  + amntSnackPerDay +"<br>");
// document.write("You will need  " +  cacu   + favSnack +  " to last until the ripe old age " +maxAge); 




// chptr # 6 - 9


// 01
// var a = 10;
// document.write("Result: " +"<br>");
// document.write("The value of a is: "  + a +"<br>");
// a++;
// document.write(".................................. "  + "<br> <br>");
// document.write("The value of a ++ is:  "  + a + "<br>");
// document.write(" Now the value of a is:  "  + a + "<br> <br>");
// document.write("The value of a ++ is:  "  + a + "<br>");
// a++;
// document.write(" Now the value of a is:  "  + a + "<br> <br>");
// --a;
// document.write("The value of a-- is:  "  + a + "<br>");
// document.write(" Now the value of a is:  "  + a + "<br> <br>");
// document.write("The value of a is:  "  + a + "<br>");
// --a;
// document.write(" Now the value of a-- is:  "  + a + "<br> <br>");

// 02  
// var a=2;
// var b=1;
// var result;
// result = --a - --b + ++b + b--;
// document.write("a is " +a + "<br>");
// document.write("b is "+ b + "<br>");
// document.write("result is " + result + "<br>");


// 03
// var name = prompt("Enter your name Please!");
// name=name.toUpperCase();
// alert("Hello! " + name + " to my page ...");



// 04  something missing
// var num = prompt("Enter a number");
// if(isNaN(num) || num === null || num == 0){
// 	num = 5;
// }
// var initial = 1;
// for(var count = 1; count<=10; count++)
// {
// 	initial = count*num;
// 	document.writeln(num+" x "+ count+"="+initial+"<br />");
// }
// function isNumeric(num){
//   return !isNaN(num)
// }


// 05  wrongly done
// var subj1 = prompt("Enter your Subject1");
// // var subj2 = prompt("Enter your Subject2");
// // var subj3= prompt("Enter your Subject3");
// var totalMarks = 100;
// var percentage;

// percentage = (obtainedMarks/totalMarks) * 100;
// var obtainedMarks = (parseFloat(obtainedMarks1));
// // percentage = ( obtainedMarks2 /totalMarks  ) * 100;
// // percentage = ( obtainedMarks3 /totalMarks  ) * 100;
// var obtainedMarks1 = prompt("Enter your obtainedmarks1");
// // var obtainedMarks2 = prompt("Enter your obtainedmarks2");
// // var obtainedMarks3 = prompt("Enter your obtainedmarks3");
// // document.write("<table>");
// // document.write("<tr>");
// // document.write("<th>  Subject </th>");
// // document.write("<th>  Total Marks </th>");
// // document.write("<th>  Obtained Marks </th>");
// // dcument.write("<th>  Percentage </th>");
// // cument.write("</tr>");



// document.write(subj1 + totalMarks + obtainedMarks1 + percentage);


// // +parseFloat(obtainedMarks2)+parseFloat(obtainedMarks3)

// chptr 9-11


// 01
// var city= prompt("Enter your City name ");
// city= city.toLowerCase();
// var str = "karachi";
// if(city === str)
// {
//     document.write("Welcome to city of lights");
// }
// else{
//     document.write("You entered an other city");
// }

// 02
// var gender= prompt("Enter your Gender ");
// gender= gender.toLowerCase();
// if(gender === "male"){
//     document.write("Good Morning Sir");
// }
// else{
//     document.write("Good Morning Ma'am");
// }

// 03     MISSING MESSAGE IN TABLE FORMAT
// var trafficLights = prompt("Please! Input color of road traffic signal ");
// trafficLights = trafficLights.toLowerCase();
// var red = "red";
// var green = "green";
// var yellow = "yellow";
// if(trafficLights === red){
//     document.write("Must Stop");
// }

//     else if  ( trafficLights === green ) {
//         document.write("Move now");
//      }
//      else {
//         document.write("Ready to move");
//      }

// 04
// var fuel = prompt("Please! Input remaining fuel in car ");
// var fuelRemain=(parseFloat(fuel));

// if (fuelRemain < 0.24){
//     document.write("Please refill the fuel in your car");
// }
// else {
//             document.write("You have enough fuel to go");
//          }


// 05  undone now



// 06
 

// 07
// var usernumber = prompt('What is your number?');
// var numbers = ['1', '2', '3','4','5','6','7','8','9','10'];
// for(i=0;i<=numbers.length;i++)    
//  {if (usernumber == numbers[i]) 

// {
//     alert('Bingo! Correct answer');
//      break;
// } }
//  if(i==numbers.length +1) {
//     alert('Close enough to the correct answer');
// }


// 08
// var number = prompt("Enter your favourite number ");
// if (number % 3 == 0){
//     alert("The given number is divisible by 3");
// }
// else{
//     alert("The given number is not divisible by 3");
// }



// 09
// var number = prompt("Enter your favourite number ");
// if (number % 2 == 0){
//     alert("The given number Even");
// }
// else{
//    alert("The given number is Odd");
//     }


// 10
// var temp = prompt("Enter Temperature");
// if (temp > 40){
//     alert("It is too hot outside");
// }
// else if (temp > 30){
//     alert("The Weather today is Normal");
// }
// else if (temp > 20){
//     alert("Today’s Weather is cool");
// }
// else if (temp > 10){
//     alert("OMG! Today’s weather is so Cool");
// }
// else{
//     alert("its Hard to survive");
// }


// 11
// var firstNum = prompt("Enter First Operand");
// var secondtNum  = prompt("Enter second Operand");
// var operator  = prompt("Enter Operator");
// var op1 = (parseInt(firstNum));
// var op2= (parseInt(secondtNum));
// var result = op1 + op2;
// var result2 = op1 - op2;
// var result3 = op1 * op2;
// var result4 = op1 / op2;
// var result5 = op1 % op2;

// if (operator === "+" ){
//     document.write("The result is: " +  result);  
// }
// else if (operator === "-"){
//     document.write("The result is: " +  result2);
// }
// else if (operator === "*"){
//     document.write("The result is: " +  result3);
// }
// else if (operator === "/"){
//     document.write("The result is: " +  result4);
// }
// else if (operator === "%"){
//     document.write("The result is: " +  result5);
// }
// else{
//     document.write("You entered something unknown");
// }



// chptr 12- 13


// 01     needs to re check
// var Character = prompt("Please! Enter");
// if (Character === '0' ||Character === '1 '|| Character === '2' || Character === '3' || Character === '4' || Character === '5' || Character === '7' || Character === '8' || Character === '9'  ){
//     document.write("You typed a number");
// }
// else if (Character === "A" || Character === "Z" ){
//     document.write("You typed a uppercase letter");
// }
// else if (Character === "a" || Character === "z" ){
//     document.write("You typed a lowercase letter");
// }

// 02
// var num = prompt("Enter an Integer");
// var num1 = prompt("Enter an other Integer");
// var number = (parseInt(num));
// var otherNumber = (parseInt(num1));
// if(number>otherNumber){
//     document.write(number);
// }
// else if(number===otherNumber){
//     document.write(number +    "  eual to  " + otherNumber);
// }


// 03
// var num = prompt("Enter Number");
// var num1=(parseInt(num));
// if (num1 < 0){
//     document.write("The number is Negative");
// }
// else if(num1 >0){
//     document.write("The number is Positive");
// }
// else if(num1 === 0){
//     document.write("The number is Zero");
// }



// 04
// var str = prompt("Enter Character");
// str=str.toLowerCase();
// if (str === 'a' ||str === 'b' ||str === 'i' || str === 'o' || str === 'u'){
//     alert("True");
// }
// else{
//     alert("False");   
//}

// 05



// 06
// var greeting ='Good day'; 
// var hour = 13; 
// if (hour < 18) { 
//     document.write(greeting);
// }
// else{
// document.write("Good Evening");
//  } 

// 07
// var time = prompt("Input time as 24 hours clock format");
// var timeformat = (parseInt(time));
// if (timeformat >= 0000 && time < 1200){
//  document.write( "Good Morning");
// }
//    else if (timeformat >= 1700 && time < 2100){
//     document.write( "Good Evening");
//    }
//    else if (timeformat >= 2100 && time < 2359){
//     document.write( "Good Night");
//    }


// chptr 14 - 16



// 01
// var arr = [];

// 02
// var cars = new Array();
// var person = [[], {}];


// 03
// var fruits = ['BAnana','Apple','kiwi','Orange'];

// 04
// var num = [1,2,3,4,5];

// 05
// var value = [true,false];

// 06
// var mixed = [1,'cat',true];

// 07     a matter of displacement
// var edu = [ 'SSC', 'HSC', 'BCS', 'BS', 'BCOM', 'MS', 'MPhil', 'PhD'];
// document.write("<h1>Qualifications</h1>");
// document.write(edu +'<br />' );


// 08
// var names = ['Micheal','John','Tony'];
// var score= [320,230,480];
// var totalMarks = 500;
// var percent = (320/500) * 100 ;
// var percent1 = (230/500) * 100 ;
// var percent2 = (480/500) * 100 ;
// document.write("Score of  " + names[0] + " is " + score[0] + "  Percentage: " +percent + "%"+ "<br>" );
// document.write("Score of  " + names[1] + "  is " + score[1] + "  Percentage: " +percent1 + "%" + "<br>"  );
// document.write("Score of  " + names[2] + "  is " + score[2] + "  Percentage: " +percent2 + "%"  + "<br>"  );

// 09


// 10
// var scores= [320,230,480,120];
// document.write("Scores of Students: " + scores + "<br>");
// scores.sort();
// document.write("Ordered Scores of Students: " + scores);

// 11
// var cities = ['Karachi','Lahore','Islamabad','Quetta','Peshawar'];
// var selectedCities= [];
// document.write("Cities List: " + "<br>");
// document.write(cities+ "<br>");
// document.write("Selected Cities List: " + "<br>");
// document.write(cities.slice(2,4) + "<br>");


// 12
// var arr = ["This", "is ", "my ", " cat"]; 
// document.write(arr + "<br>");
// document.write(arr.join( " " ));


// 13
// var devices = ["Keyboard", "Mouse ", "Printer", " Monitor"]; 
// document.write("devices:" + "<br>");
// document.write(devices + "<br> <br>");
// document.write("Out:" + "<br>");
// document.write(devices[0] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[1] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[2] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[3]);


// 14
// var devices = ["Keyboard", "Mouse ", "Printer", " Monitor"]; 
// document.write("devices:" + "<br>");
// document.write(devices + "<br> <br>");
// document.write("Out:" + "<br>");
// document.write(devices[3] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[2] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[1] + "<br>");
// document.write("Out:" + "<br>");
// document.write(devices[0]);


// 15
// var companies = ["Apple", "Samsung ", "Motrola", " Sony","Haier"]; 
// document.write("<select>");
// for (var i= 0; i < companies.length; i ++){
// document.write("<option>" + companies[i]+"</option>");
// }
// document.write("</select>");


// chptr 17 - 20
// 01
// let activities = [[ ],[]];

// 02
let activities = [
    [0, 1,2,3],
    [1, 0,1,2],
    [2, 1,0,1]
];
document.write(activities.join( "   "));























































































































